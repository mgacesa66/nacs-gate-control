# Publication plan status — 2026-11-02

The authoritative six-step plan is frozen in `PUBLICATION_PLAN_FROZEN.md` and remains unchanged.

- Step 1 — complete as a conditional molecular-parameter/recalibration study (`v0.2.0.dev1`).
- **Step 2 — completed systematic screened-basis audit (`v0.2.0.dev2`)**: independently microwave- and dipolar-ranked selected spaces up to 25 dressed states/molecule; preserved output matrices and tests. Full two-molecule 128² propagation was not done and full rigorous convergence is **not** claimed.
- Step 3 — next: matched control-objective optimization with equal hardware budgets and smooth phase bandwidth.
- Step 4 — literature and novelty audit, pending.
- Step 5 — manuscript and figures, pending.
- Step 6 — freeze code and submit, pending.

This is a versioned *status update*, not a rewrite of the original frozen plan.
